# Maven project instructions for Eclipse users
https://github.com/jimmyxle/COMP354_CODENAMES/wiki/Setup%3A-For-Eclipse-Users

# COMP354_CODENAMES
Winter 2019 project for COMP 354
Taught by Gregory Butler

**Getting Started**  
Please read carefully the guide below to install and run the game properly. Those instruction will help you run the game on your local machine for development and testing purpose.

***Installation & Setup***  

**Technology used/Built with**  
Language used: -Java
IDE: 


**About the game**  



**Rules/How to play**  




**Authors**  
* Alexandre	Abrams
* Alexandre	Briere
* Yaacov	Cohen
* Zachary	Hynes
* Christopher	Idah
* Alexandre-Molyvan	Kang
* Elie	Khoury
* Jimmy	Le
* Mykyta	Leonidov
* Vickel	Leung
* Hoai An	Luu
